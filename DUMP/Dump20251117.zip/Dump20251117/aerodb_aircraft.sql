CREATE DATABASE  IF NOT EXISTS `aerodb` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `aerodb`;
-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: aerodb
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `aircraft`
--

DROP TABLE IF EXISTS `aircraft`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aircraft` (
  `AircraftID` int NOT NULL AUTO_INCREMENT,
  `Model` varchar(50) NOT NULL,
  `Capacity` int NOT NULL,
  `Status` varchar(20) NOT NULL,
  PRIMARY KEY (`AircraftID`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aircraft`
--

LOCK TABLES `aircraft` WRITE;
/*!40000 ALTER TABLE `aircraft` DISABLE KEYS */;
INSERT INTO `aircraft` VALUES (1,'Boeing 737',122,'Maintenance'),(2,'Boeing 787',164,'Retired'),(3,'Boeing 787',160,'Active'),(4,'Boeing 787',126,'Active'),(5,'Airbus A320',166,'Retired'),(6,'Boeing 787',208,'Maintenance'),(7,'Airbus A320',161,'Retired'),(8,'Boeing 787',146,'Maintenance'),(9,'Airbus A350',290,'Active'),(10,'Boeing 787',249,'Retired'),(11,'Embraer E190',133,'Maintenance'),(12,'Boeing 787',202,'Active'),(13,'Airbus A320',164,'Retired'),(14,'Embraer E190',191,'Retired'),(15,'Airbus A350',134,'Retired'),(16,'Embraer E190',283,'Active'),(17,'Embraer E190',148,'Active'),(18,'Boeing 737',221,'Active'),(19,'Airbus A350',141,'Maintenance'),(20,'Embraer E190',176,'Active'),(21,'Airbus A350',145,'Retired'),(22,'Boeing 787',280,'Retired'),(23,'Boeing 737',286,'Active'),(24,'Airbus A350',203,'Maintenance'),(25,'Airbus A320',189,'Retired'),(26,'Airbus A350',230,'Retired'),(27,'Embraer E190',195,'Retired'),(28,'Airbus A320',190,'Retired'),(29,'Boeing 737',232,'Retired'),(30,'Embraer E190',196,'Retired'),(31,'Airbus A350',124,'Retired'),(32,'Airbus A350',136,'Active'),(33,'Boeing 737',161,'Active'),(34,'Boeing 787',212,'Maintenance'),(35,'Embraer E190',226,'Active'),(36,'Airbus A350',181,'Retired'),(37,'Airbus A320',272,'Retired'),(38,'Airbus A350',135,'Maintenance'),(39,'Boeing 787',244,'Maintenance'),(40,'Airbus A320',155,'Retired');
/*!40000 ALTER TABLE `aircraft` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-17 21:06:56
